Flexium API - Automated testing for Apache Flex and Selenium
=======

Flexium is a tool used for building automated [Selenium](http://seleniumhq.org/) tests.<br/>
Flexium is a work in progress, only having basic functionality (yet).

